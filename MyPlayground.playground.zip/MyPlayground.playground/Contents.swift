import UIKit

/* This program will serve to be a variable
 declaration of a bands song which are then
 printed to the UI console*/

// Variable Declaration

var artist : String = "Dire Straits"
var genre : String = "Rock"
var title : String = "Brothers In Arms"
var album : String = "MCMX#14"      // album code
var tracks: Int8 = 9
var length : Int = 109

// Print to UI

print("Artist : ", artist)
print("Genre : ",genre)
print("Title :", title)
print("Album :",album)
print("Tracks :", tracks)
print("Length :", length,"minutes")



        
